import React from 'react';
import { formatTextWithBreaks } from '@/lib/formatText';

// script to transform <br> tags coming from the backend into line breaks in the frontend
export function Text({
  children,
  as: Component = 'span',
  className,
  ...props
}: {
  children?: string;
  as?: any;
  className?: string;
  [key: string]: any;
}) {
  return React.createElement(Component as any, { className, ...props }, formatTextWithBreaks(children || ''));
}
