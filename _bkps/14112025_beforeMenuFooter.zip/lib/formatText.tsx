import React, { ElementType } from 'react';

export function formatTextWithBreaks(text: string): React.ReactNode[] {
  if (!text) return [];
  
  // Split the text by <br> or <br/> or <br /> tags
  const parts = text.split(/(<br\s*\/?>)/i);
  
  // Map through parts and replace br tags with line breaks
  return parts.map((part, index) => {
    if (part.match(/<br\s*\/?>/i)) {
      return <br key={index} />;
    }
    return <span key={index}>{part}</span>;
  });
}

// NOTE: Text component moved to /components/configs/text.tsx to avoid mixing with content components