import Link from "next/link";
import { Text } from "../configs/text";
import { StrapiImage } from "../../lib/strapi-image";

const styles = {
  footer: "footer",
  footerContent: "footerContent",
  footerColumns: "footerColumns",
  footerLogoSection: "footerLogoSection",
  footerLogo: "footerLogo",
  footerLogoImage: "footerLogoImage",
  footerHeading: "footerHeading",
  socialMedias: "socialMedias",
  socialIcon: "socialIcon",
  footerSubHeading: "footerSubHeading",
  footerLink: "footerLink",
  footerCategory: "footerCategory",
  footerCategoryHeading: "footerCategoryHeading",
  categoryPages: "categoryPages",
  categoryPageLink: "categoryPageLink",
  footerCategoryLinkToAll: "footerCategoryLinkToAll",
  footerBar: "footerBar",
  barLinks: "barLinks",
  barLink: "barLink",
  legalText: "legalText",
};

// Types
export interface IImage {
  url: string;
  alternativeText?: string | null;
}

export interface ILink {
  href: string;
  label: string;
  isExternal: boolean;
}

export interface ILogoComponent {
  logo?: IImage | null;
  href?: string;
  label?: string;
  isExternal?: boolean;
}

export interface ISocialIcon {
  id: number;
  logo: IImage;
  href: string;
  label: string;
  isExternal: boolean;
}

export interface ISocialMedias {
  socialIcon: ISocialIcon[];
}

export interface ICategoryPage {
  id: number;
  href: string;
  label: string;
  isExternal: boolean;
}

export interface IFooterCategory {
  id: number;
  heading: string;
  categoryPage: ICategoryPage[];
  linkToAll?: ILink | null;
}

export interface IBarLink {
  id: number;
  href: string;
  label: string;
  isExternal: boolean;
}

export interface IFooterBar {
  barLink: IBarLink[];
  legalText: string;
}

export interface IFooterProps {
  logo: ILogoComponent;
  heading: string;
  socialMedias: ISocialMedias;
  subHeading?: string | null;
  link?: ILink | null;
  FooterCategories: IFooterCategory[];
  FooterBar: IFooterBar;
}

export function Footer({ data }: { data: IFooterProps }) {
  if (!data) return null;

  const {
    logo,
    heading,
    socialMedias,
    subHeading,
    link,
    FooterCategories,
    FooterBar,
  } = data;

  return (
    <footer className={styles.footer}>
      <div className={styles.footerContent}>
        <div className={styles.footerColumns}>
          {/* Logo Section */}
          <div className={styles.footerLogoSection}>
            {logo && (
              <Link
                href={logo.href || "/"}
                target={logo.isExternal ? "_blank" : "_self"}
                className={styles.footerLogo}
              >
                {logo.logo && (
                  <StrapiImage
                    src={logo.logo.url}
                    alt={logo.label || "Footer Logo"}
                    className={styles.footerLogoImage}
                    width={40}
                    height={40}
                  />
                )}
                {logo.label && (
                  <Text className={styles.footerHeading}>{logo.label}</Text>
                )}
              </Link>
            )}

            <Text as="h5" className={styles.footerHeading}>
              {heading}
            </Text>

            {socialMedias && (
              <div className={styles.socialMedias}>
                {socialMedias.socialIcon.map(social => (
                  <Link
                    key={social.id}
                    href={social.href}
                    target={social.isExternal ? "_blank" : "_self"}
                    title={social.label}
                    className={styles.socialIcon}
                  >
                    <StrapiImage
                      src={social.logo.url}
                      alt={social.label}
                      width={24}
                      height={24}
                    />
                  </Link>
                ))}
              </div>
            )}

            {subHeading && (
              <Text className={styles.footerSubHeading}>{subHeading}</Text>
            )}

            {link && (
              <Link
                href={link.href}
                target={link.isExternal ? "_blank" : "_self"}
                className={styles.footerLink}
              >
                <Text>{link.label}</Text>
              </Link>
            )}
          </div>

          {/* Categories */}
          {FooterCategories && FooterCategories.map(category => (
            <div key={category.id} className={styles.footerCategory}>
              <Text as="h5" className={styles.footerCategoryHeading}>
                {category.heading}
              </Text>
              <ul className={styles.categoryPages}>
                {category.categoryPage && category.categoryPage.map(page => (
                  <li key={page.id}>
                    <Link
                      href={page.href}
                      target={page.isExternal ? "_blank" : "_self"}
                      className={styles.categoryPageLink}
                    >
                      <Text>{page.label}</Text>
                    </Link>
                  </li>
                ))}
              </ul>
              {category.linkToAll && (
                <Link
                  href={category.linkToAll.href}
                  target={category.linkToAll.isExternal ? "_blank" : "_self"}
                  className={styles.footerCategoryLinkToAll}
                >
                  <Text>{category.linkToAll.label}</Text>
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Footer Bar */}
      {FooterBar && (
        <div className={styles.footerBar}>
          <div className={styles.barLinks}>
            {FooterBar.barLink && FooterBar.barLink.map(link => (
              <Link
                key={link.id}
                href={link.href}
                target={link.isExternal ? "_blank" : "_self"}
                className={styles.barLink}
              >
                <Text>{link.label}</Text>
              </Link>
            ))}
          </div>
          <Text className={styles.legalText}>{FooterBar.legalText}</Text>
        </div>
      )}
    </footer>
  );
}

export default Footer;
