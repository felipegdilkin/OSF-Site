"use client";

import { useState } from "react";
import Link from "next/link";
import { Text } from "../configs/text";
import { StrapiImage } from "../../lib/strapi-image";

const styles = {
  menu: "menu",
  menuContainer: "menuContainer",
  menuLeft: "menuLeft",
  menuLogo: "menuLogo",
  menuCenter: "menuCenter",
  menuCategory: "menuCategory",
  menuCategoryButton: "menuCategoryButton",
  menuCategoryButtonActive: "menuCategoryButton--active",
  expandPanel: "expandPanel",
  panelContent: "panelContent",
  panelLeft: "panelLeft",
  panelRight: "panelRight",
  categoryLinks: "categoryLinks",
  categoryLink: "categoryLink",
  linkToAll: "linkToAll",
  panelBanners: "panelBanners",
  bannerItem: "bannerItem",
  bannerImage: "bannerImage",
  bannerText: "bannerText",
  bannerHeading: "bannerHeading",
  bannerSubheading: "bannerSubheading",
  menuRight: "menuRight",
  menuButton: "menuButton",
  searchButton: "searchButton",
  colorThemeSwitch: "colorThemeSwitch",
  contactButton: "contactButton",
  languageSwitch: "languageSwitch",
  languageList: "languageList",
  languageItem: "languageItem",
};

// Types
export interface IImage {
  url: string;
  alternativeText?: string | null;
}

export interface ILink {
  href: string;
  label: string;
  isExternal: boolean;
}

export interface ILogoComponent {
  image?: IImage | null;
  href?: string;
  label?: string;
  isExternal?: boolean;
}

export interface ICategoryLink {
  id: number;
  href: string;
  label: string;
  isExternal: boolean;
}

export interface IPanelCategories {
  categoryLink: ICategoryLink[];
  linkToAll?: ILink | null;
}

export interface ICategoryBanner {
  id: number;
  image: IImage;
  heading: string;
  subHeading?: string | null;
  href: string;
  isExternal: boolean;
}

export interface IPanelBanners {
  heading: string;
  subHeading?: string | null;
  categoryBanner: ICategoryBanner[];
}

export interface IMenuCategory {
  id: number;
  categoryName: string;
  pannelCategories: IPanelCategories;
  pannelBanners: IPanelBanners;
}

export interface ILanguage {
  id: number;
  flagIcon: IImage;
  languageName: string;
  href: string;
}

export interface ILanguageSwitch {
  language: ILanguage[];
}

export interface ISearchButton {
  icon: IImage;
  href: string;
}

export interface IColorThemeSwitch {
  icon: IImage;
  label: string;
  href: string;
}

export interface IContactButton {
  icon?: IImage | null;
  label: string;
  href: string;
  isExternal: boolean;
}

export interface IMenuProps {
  logo: ILogoComponent;
  menuCategory: IMenuCategory[];
  searchButton?: ISearchButton;
  colorThemeSwitch?: IColorThemeSwitch;
  contactButton?: IContactButton;
  languageSwitch?: ILanguageSwitch;
}

export function Menu({ data }: { data: IMenuProps }) {
  if (!data) return null;

  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  const {
    logo,
    menuCategory,
    searchButton,
    colorThemeSwitch,
    contactButton,
    languageSwitch,
  } = data;

  const active = menuCategory && menuCategory.find(cat => cat.id === activeCategory);

  return (
    <header className={styles.menu}>
      <nav className={styles.menuContainer}>
        {/* Left: Logo */}
        <div className={styles.menuLeft}>
          {logo && (
            <Link href={logo.href || "/"} className={styles.menuLogo}>
              {logo.image && (
                <StrapiImage
                  src={logo.image.url}
                  alt={logo.label || "Logo"}
                  width={40}
                  height={40}
                />
              )}
              {logo.label && <Text>{logo.label}</Text>}
            </Link>
          )}
        </div>

        {/* Center: Menu Categories */}
        <div className={styles.menuCenter}>
          {menuCategory && menuCategory.map(cat => (
            <button
              key={cat.id}
              className={`${styles.menuCategory} ${
                activeCategory === cat.id ? styles.menuCategoryButtonActive : ""
              }`}
              onClick={() =>
                setActiveCategory(activeCategory === cat.id ? null : cat.id)
              }
            >
              <Text>{cat.categoryName}</Text>
            </button>
          ))}
        </div>

        {/* Right: Action Buttons */}
        <div className={styles.menuRight}>
          {searchButton && (
            <button className={styles.searchButton} title="Search">
              {searchButton.icon && (
                <StrapiImage
                  src={searchButton.icon.url}
                  alt="Search"
                  width={24}
                  height={24}
                />
              )}
            </button>
          )}

          {colorThemeSwitch && (
            <button className={styles.colorThemeSwitch} title="Toggle theme">
              {colorThemeSwitch.icon && (
                <StrapiImage
                  src={colorThemeSwitch.icon.url}
                  alt={colorThemeSwitch.label}
                  width={24}
                  height={24}
                />
              )}
            </button>
          )}

          {contactButton && (
            <Link
              href={contactButton.href}
              target={contactButton.isExternal ? "_blank" : "_self"}
              className={styles.contactButton}
            >
              {contactButton.icon && (
                <StrapiImage
                  src={contactButton.icon.url}
                  alt={contactButton.label}
                  width={20}
                  height={20}
                />
              )}
              <Text>{contactButton.label}</Text>
            </Link>
          )}

          {languageSwitch && (
            <div className={styles.languageSwitch}>
              <ul className={styles.languageList}>
                {languageSwitch.language.map(lang => (
                  <li key={lang.id} className={styles.languageItem}>
                    <Link href={lang.href}>
                      {lang.flagIcon && (
                        <StrapiImage
                          src={lang.flagIcon.url}
                          alt={lang.languageName}
                          width={20}
                          height={14}
                        />
                      )}
                      <Text>{lang.languageName}</Text>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </nav>

      {/* Expand Panel */}
      {active && (
        <div className={styles.expandPanel}>
          <div className={styles.panelContent}>
            {/* Left: Categories */}
            <div className={styles.panelLeft}>
              <ul className={styles.categoryLinks}>
                {active.pannelCategories.categoryLink.map(link => (
                  <li key={link.id}>
                    <Link
                      href={link.href}
                      target={link.isExternal ? "_blank" : "_self"}
                      className={styles.categoryLink}
                    >
                      <Text>{link.label}</Text>
                    </Link>
                  </li>
                ))}
              </ul>
              {active.pannelCategories.linkToAll && (
                <Link
                  href={active.pannelCategories.linkToAll.href}
                  target={
                    active.pannelCategories.linkToAll.isExternal
                      ? "_blank"
                      : "_self"
                  }
                  className={styles.linkToAll}
                >
                  <Text>{active.pannelCategories.linkToAll.label}</Text>
                </Link>
              )}
            </div>

            {/* Right: Banners */}
            <div className={styles.panelRight}>
              <Text as="h4" className={styles.bannerHeading}>
                {active.pannelBanners.heading}
              </Text>
              {active.pannelBanners.subHeading && (
                <Text as="p" className={styles.bannerSubheading}>
                  {active.pannelBanners.subHeading}
                </Text>
              )}
              <div className={styles.panelBanners}>
                {active.pannelBanners.categoryBanner.map(banner => (
                  <Link
                    key={banner.id}
                    href={banner.href}
                    target={banner.isExternal ? "_blank" : "_self"}
                    className={styles.bannerItem}
                  >
                    {banner.image && (
                      <StrapiImage
                        src={banner.image.url}
                        alt={banner.heading}
                        className={styles.bannerImage}
                        width={140}
                        height={120}
                      />
                    )}
                    <div className={styles.bannerText}>
                      <Text as="h5">{banner.heading}</Text>
                      {banner.subHeading && <Text as="p">{banner.subHeading}</Text>}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export default Menu;
