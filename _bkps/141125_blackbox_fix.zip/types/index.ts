export interface TImage {
  url: string;
  alternativeText?: string | null;
}

export interface TLink {
  href: string;
  label: string;
  isExternal: boolean;
}

export interface TStrapiResponse<T> {
  data: T;
  meta?: any;
  success: boolean;
  status: number;
  error?: {
    status: number;
    name: string;
    message: string;
  };
}

export interface THomePage {
  blocks: any[];
  // Add other fields as needed
}

// Add more types as needed for Menu and Footer
export interface IMenuData {
  // Define based on Menu component props
  // From menu.tsx, it's IMenuProps which has MenuCategories, etc.
  // But for simplicity, use any for now
  [key: string]: any;
}

export interface IFooterData {
  // Define based on Footer component props
  [key: string]: any;
}

export interface TGlobalData {
  Menu: IMenuData;
  Footer: IFooterData;
}
